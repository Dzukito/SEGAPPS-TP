<?php
/**
 * The base configuration for WordPress
 *
 * The wp-config.php creation script uses this file during the
 * installation. You don't have to use the web site, you can
 * copy this file to "wp-config.php" and fill in the values.
 *
 * This file contains the following configurations:
 *
 * * MySQL settings
 * * Secret keys
 * * Database table prefix
 * * ABSPATH
 *
 * @link https://wordpress.org/support/article/editing-wp-config-php/
 *
 * @package WordPress
 */

// ** MySQL settings - You can get this info from your web host ** //
/** The name of the database for WordPress */
define( 'DB_NAME', 'si2020' );

/** MySQL database username */
define( 'DB_USER', 'root' );

/** MySQL database password */
define( 'DB_PASSWORD', '' );

/** MySQL hostname */
define( 'DB_HOST', 'localhost' );

/** Database Charset to use in creating database tables. */
define( 'DB_CHARSET', 'utf8mb4' );

/** The Database Collate type. Don't change this if in doubt. */
define( 'DB_COLLATE', '' );

/**#@+
 * Authentication Unique Keys and Salts.
 *
 * Change these to different unique phrases!
 * You can generate these using the {@link https://api.wordpress.org/secret-key/1.1/salt/ WordPress.org secret-key service}
 * You can change these at any point in time to invalidate all existing cookies. This will force all users to have to log in again.
 *
 * @since 2.6.0
 */
define( 'AUTH_KEY',         '`G]<quei)Zh&# /A%wq(,qw_efP`0.k<4g)sV=j,vRjtt_8vFLB}f_6Cd[+@zX]k' );
define( 'SECURE_AUTH_KEY',  '#Ao%XZ:eyIMtW_Y1?-WBEy$Kl]T9EUaV6x3ZT&_zvJC]L%pLb&QC_)U{zQgl$!=O' );
define( 'LOGGED_IN_KEY',    'RVmM^@%q<U&6(p2C!%A)pLf3WM MNzY&~W`v0LN;Q]+R&5t~KN#5l{`Ucl/0L;1x' );
define( 'NONCE_KEY',        'h.;f5mIN*<,sdW%*hq2QJR`A<PO<P?]1u(2h)n|w~uM16@,em{:rI|BNY{N&eQv~' );
define( 'AUTH_SALT',        '^MT_63XwpXO`ghF$IUN%W^G`oE@bmk!gM/{MG $h(N`VzE.v^_(plNl^=b<aKm4<' );
define( 'SECURE_AUTH_SALT', 'mEV0?~%whh+);SJ@?zr^ Fh-h,{UKD?|)z3yfQ~4ssa,9mCm&rB2XZE~aK.t.ph=' );
define( 'LOGGED_IN_SALT',   'zb+L{!EL~-.Vm3xtN*IXYL.^6[5IJ++HTb(d<aJM$-J`:GNZeg~s~~Y,IuuO2wWe' );
define( 'NONCE_SALT',       'd8GTe%9:4r)g^AU>T:]vtKyL$);Z&u(Tk[ox;=r b<fi>r)_)H1eo@8+}F{-V.A^' );

/**#@-*/

/**
 * WordPress Database Table prefix.
 *
 * You can have multiple installations in one database if you give each
 * a unique prefix. Only numbers, letters, and underscores please!
 */
$table_prefix = 'wp_';

/**
 * For developers: WordPress debugging mode.
 *
 * Change this to true to enable the display of notices during development.
 * It is strongly recommended that plugin and theme developers use WP_DEBUG
 * in their development environments.
 *
 * For information on other constants that can be used for debugging,
 * visit the documentation.
 *
 * @link https://wordpress.org/support/article/debugging-in-wordpress/
 */
define( 'WP_DEBUG', false );

/* That's all, stop editing! Happy publishing. */

/** Absolute path to the WordPress directory. */
if ( ! defined( 'ABSPATH' ) ) {
	define( 'ABSPATH', __DIR__ . '/' );
}

/** Sets up WordPress vars and included files. */
require_once ABSPATH . 'wp-settings.php';
